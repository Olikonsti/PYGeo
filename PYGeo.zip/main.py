from tkinter import *
import tkinter.ttk as ttk
from GEOWINDOW import *

root = GeoWindow()

root.mainloop()